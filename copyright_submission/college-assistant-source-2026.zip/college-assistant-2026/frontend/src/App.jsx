// Copyright (c) 2026 Yash Garad. All rights reserved.

import { useEffect, useState } from "react";

import Chat from "./components/Chat";
import Login from "./components/Login";
import { ensureCsrf, getMe, logout } from "./api";

function App() {
  const [username, setUsername] = useState(null);
  const [loading, setLoading] = useState(true);

  // On load: make sure we have a CSRF cookie, then ask the server whether we
  // already have a valid session (rather than trusting any client-side state).
  useEffect(() => {
    (async () => {
      await ensureCsrf();
      const me = await getMe();
      setUsername(me?.username ?? null);
      setLoading(false);
    })();
  }, []);

  async function handleLogout() {
    await logout();
    setUsername(null);
  }

  function handleSessionExpired() {
    // Session was rejected mid-use — bounce back to login.
    setUsername(null);
  }

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-slate-900 text-slate-400">
        Loading…
      </div>
    );
  }

  if (!username) {
    return <Login onLoggedIn={setUsername} />;
  }

  return (
    <Chat username={username} onLogout={handleLogout} onSessionExpired={handleSessionExpired} />
  );
}

export default App;
