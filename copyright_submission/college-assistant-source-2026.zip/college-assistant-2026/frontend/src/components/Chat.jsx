// Copyright (c) 2026 Yash Garad. All rights reserved.

import { useEffect, useRef, useState } from "react";

import { askStream } from "../api";

function RouteBadge({ route }) {
  if (!route) return null;
  const colors = {
    SQL: "bg-sky-900 text-sky-300",
    RAG: "bg-violet-900 text-violet-300",
    BOTH: "bg-amber-900 text-amber-300",
  };
  return (
    <span className={`ml-2 rounded px-1.5 py-0.5 text-[10px] font-semibold uppercase ${colors[route] || "bg-slate-700 text-slate-300"}`}>
      {route}
    </span>
  );
}

function Chat({ username, onLogout, onSessionExpired }) {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const scrollRef = useRef(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages]);

  async function handleSubmit(e) {
    e.preventDefault();
    const question = input.trim();
    if (!question || busy) return;

    setInput("");
    setBusy(true);
    setMessages((prev) => [...prev, { role: "user", text: question }]);
    // Placeholder assistant message we fill in as tokens stream in.
    const assistantIndex = messages.length + 1;
    setMessages((prev) => [...prev, { role: "assistant", text: "", route: null, pending: true }]);

    const update = (patch) =>
      setMessages((prev) => {
        const next = [...prev];
        next[assistantIndex] = { ...next[assistantIndex], ...patch(next[assistantIndex]) };
        return next;
      });

    let expired = false;
    const result = await askStream(question, {
      onMeta: (meta) => update((m) => ({ route: meta.route, pending: true })),
      onToken: (text) => update((m) => ({ text: m.text + text, pending: false })),
      onDone: (final) => update((m) => ({ text: final || m.text, pending: false })),
      onError: (msg) => {
        if (msg.toLowerCase().includes("authorized")) expired = true;
        update((m) => ({ text: m.text || `⚠️ ${msg}`, error: true, pending: false }));
      },
    }).catch((err) => {
      update((m) => ({ text: `⚠️ ${err.message}`, error: true, pending: false }));
      return {};
    });

    setBusy(false);
    if (expired || result?.unauthorized) onSessionExpired();
  }

  return (
    <div className="flex h-screen flex-col bg-slate-900 text-slate-100">
      <header className="flex items-center justify-between border-b border-slate-700 px-6 py-3">
        <h1 className="text-lg font-semibold">College Assistant</h1>
        <div className="flex items-center gap-3 text-sm text-slate-400">
          <span>{username}</span>
          <button
            onClick={onLogout}
            className="rounded border border-slate-600 px-2 py-1 text-slate-300 transition hover:bg-slate-800"
          >
            Sign out
          </button>
        </div>
      </header>

      <div ref={scrollRef} className="flex-1 space-y-4 overflow-y-auto px-6 py-6">
        {messages.length === 0 && (
          <div className="mx-auto mt-20 max-w-md text-center text-slate-500">
            <p className="text-lg">Ask a question about courses, departments, faculty, fees, or schedules.</p>
          </div>
        )}

        {messages.map((msg, i) => (
          <div key={i} className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}>
            <div
              className={`max-w-2xl whitespace-pre-wrap rounded-2xl px-4 py-2.5 ${
                msg.role === "user"
                  ? "bg-emerald-600 text-white"
                  : msg.error
                    ? "bg-red-950 text-red-200"
                    : "bg-slate-800 text-slate-100"
              }`}
            >
              {msg.role === "assistant" && msg.route && (
                <div className="mb-1 text-xs text-slate-400">
                  Assistant <RouteBadge route={msg.route} />
                </div>
              )}
              {msg.text}
              {msg.role === "assistant" && msg.pending && (
                <span className="ml-1 inline-block h-4 w-2 animate-pulse bg-slate-400 align-middle" />
              )}
            </div>
          </div>
        ))}
      </div>

      <form onSubmit={handleSubmit} className="border-t border-slate-700 px-6 py-4">
        <div className="flex gap-3">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask a question…"
            disabled={busy}
            className="flex-1 rounded-lg border border-slate-600 bg-slate-800 px-4 py-2.5 text-slate-100 outline-none focus:border-emerald-500 disabled:opacity-60"
          />
          <button
            type="submit"
            disabled={busy || !input.trim()}
            className="rounded-lg bg-emerald-600 px-5 py-2.5 font-medium text-white transition hover:bg-emerald-500 disabled:cursor-not-allowed disabled:opacity-60"
          >
            {busy ? "…" : "Send"}
          </button>
        </div>
      </form>
    </div>
  );
}

export default Chat;
