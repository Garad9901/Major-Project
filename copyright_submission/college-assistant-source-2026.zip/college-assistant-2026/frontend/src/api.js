// Copyright (c) 2026 Yash Garad. All rights reserved.

// Session-cookie auth: the browser holds an httpOnly session cookie (not
// readable by JS), and we send Django's CSRF token from the csrftoken cookie
// as the X-CSRFToken header on every unsafe (POST) request. Nothing sensitive
// is kept in localStorage.

function getCookie(name) {
  const match = document.cookie.match(new RegExp("(^|;\\s*)" + name + "=([^;]*)"));
  return match ? decodeURIComponent(match[2]) : null;
}

// Ask the server to set the csrftoken cookie. Call once before the first POST.
export async function ensureCsrf() {
  await fetch("/api/auth/csrf/", { credentials: "include" }).catch(() => {});
}

function csrfHeaders() {
  const token = getCookie("csrftoken");
  return token ? { "X-CSRFToken": token } : {};
}

export async function login(username, password) {
  await ensureCsrf();
  const res = await fetch("/api/auth/login/", {
    method: "POST",
    credentials: "include",
    headers: { "Content-Type": "application/json", ...csrfHeaders() },
    body: JSON.stringify({ username, password }),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(data.error || `Login failed (${res.status})`);
  }
  return data; // { username, is_staff }
}

export async function logout() {
  await fetch("/api/auth/logout/", {
    method: "POST",
    credentials: "include",
    headers: { ...csrfHeaders() },
  }).catch(() => {});
}

// Returns { username, is_staff } if a valid session exists, or null otherwise.
export async function getMe() {
  const res = await fetch("/api/auth/me/", { credentials: "include" });
  if (!res.ok) return null;
  return res.json();
}

/**
 * POST a question to /api/ask/ and stream the SSE response. Callbacks:
 *   onMeta(meta), onToken(text), onDone(final), onError(msg).
 * Returns a promise that resolves when the stream ends.
 */
export async function askStream(question, { onMeta, onToken, onDone, onError }) {
  const res = await fetch("/api/ask/", {
    method: "POST",
    credentials: "include",
    headers: { "Content-Type": "application/json", ...csrfHeaders() },
    body: JSON.stringify({ question }),
  });

  if (res.status === 401 || res.status === 403) {
    onError?.("Your session is not authorized. Please log in again.");
    return { unauthorized: true };
  }
  if (res.status === 429) {
    onError?.("You're sending questions too quickly. Please wait a moment and try again.");
    return { throttled: true };
  }
  if (!res.ok || !res.body) {
    const data = await res.json().catch(() => ({}));
    onError?.(data.error || `Request failed (${res.status})`);
    return {};
  }

  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";

  // SSE frames are separated by a blank line; parse them as they complete.
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });

    let sep;
    while ((sep = buffer.indexOf("\n\n")) !== -1) {
      const frame = buffer.slice(0, sep);
      buffer = buffer.slice(sep + 2);
      handleFrame(frame, { onMeta, onToken, onDone, onError });
    }
  }
  return {};
}

function handleFrame(frame, { onMeta, onToken, onDone, onError }) {
  let event = "message";
  let dataLine = "";
  for (const line of frame.split("\n")) {
    if (line.startsWith("event:")) event = line.slice(6).trim();
    else if (line.startsWith("data:")) dataLine += line.slice(5).trim();
  }
  if (!dataLine) return;

  let payload;
  try {
    payload = JSON.parse(dataLine);
  } catch {
    return;
  }

  if (event === "meta") onMeta?.(payload);
  else if (event === "token") onToken?.(payload.text || "");
  else if (event === "done") onDone?.(payload.answer || "");
  else if (event === "error") onError?.(payload.error || "Unknown error");
}
