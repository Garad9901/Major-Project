#!/bin/sh
# Copyright (c) 2026 Yash Garad. All rights reserved.
# Backend startup: bring the database to a ready state, then serve.
# Every step here is idempotent, so it is safe to run on every container start.
set -e

echo "[entrypoint] Applying database migrations..."
python manage.py migrate --noinput

echo "[entrypoint] Configuring read-only database role (rag_agent_ro)..."
python manage.py setup_readonly_role

echo "[entrypoint] Ensuring staff login exists..."
python manage.py create_staff_user

if [ "${SEED_DEMO_DATA:-true}" = "true" ]; then
  echo "[entrypoint] Seeding demo data (only if the database is empty)..."
  python manage.py seed_demo_data --if-empty
fi

echo "[entrypoint] Starting web server on port 8000..."
exec python manage.py runserver 0.0.0.0:8000
