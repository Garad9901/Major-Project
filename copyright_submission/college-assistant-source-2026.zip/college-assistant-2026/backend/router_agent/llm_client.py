# Copyright (c) 2026 Yash Garad. All rights reserved.

import os

from common import ollama

# LLM_MODEL is the single knob for the model all agents use; ROUTER_MODEL is
# an optional per-agent override that defaults to it.
ROUTER_MODEL = os.getenv("ROUTER_MODEL", os.getenv("LLM_MODEL", "qwen2.5:7b"))

SYSTEM_PROMPT = """You are a router that decides which backend should handle a user's question about a college information system.

There are two backends:
- SQL: a text-to-SQL agent that queries structured data directly. Use it for precise facts, counts, lists, filters, joins, numeric values, schedules, fees, or specific record lookups — anything with a single well-defined answer pulled from a table.
- RAG: a semantic search agent over descriptive text (department, faculty, program, and course descriptions). Use it for open-ended, "tell me about", "what does X cover", conceptual, or descriptive questions where there's no single precise field to look up.

Some questions genuinely need BOTH — they ask for a specific structured fact AND an open-ended description in the same question.

Given a question, respond with ONLY a JSON object of the form:
{"route": "SQL" | "RAG" | "BOTH", "reason": "<one short sentence explaining why>"}

No markdown, no extra text — just that JSON object.

Examples:

Q: How many faculty members are in the Computer Science department?
A: {"route": "SQL", "reason": "Asks for a count, a precise structured aggregate."}

Q: What does the Machine Learning Fundamentals course cover?
A: {"route": "RAG", "reason": "Open-ended request for descriptive course content."}

Q: List all programs that take longer than 3 years to complete.
A: {"route": "SQL", "reason": "A filtered list pulled from structured program data."}

Q: Tell me about the Mathematics department.
A: {"route": "RAG", "reason": "General descriptive question with no single precise field to look up."}

Q: What is the tuition fee for the Computer Science program, and can you describe what the program covers?
A: {"route": "BOTH", "reason": "Asks for a precise fee (SQL) and a descriptive summary (RAG) in one question."}

Q: When is the exam for course CS310?
A: {"route": "SQL", "reason": "A precise scheduled fact lookup."}
"""


def classify_question(question):
    # Raises common.exceptions.LLMUnavailable if Ollama is down/slow.
    return ollama.chat(
        ROUTER_MODEL,
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": question},
        ],
        options={"temperature": 0},
        response_format="json",
    )
