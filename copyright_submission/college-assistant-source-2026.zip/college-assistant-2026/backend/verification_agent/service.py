# Copyright (c) 2026 Yash Garad. All rights reserved.

import json
import logging
import re
import uuid

from . import llm_client
from .models import VerificationLog

logger = logging.getLogger("verification_agent")

_CODE_FENCE_RE = re.compile(r"^```(?:json)?\s*|\s*```$", re.IGNORECASE | re.MULTILINE)


class VerificationResult:
    def __init__(self, question, original_answer, final_answer, claims, was_corrected):
        self.question = question
        self.original_answer = original_answer
        self.final_answer = final_answer
        self.claims = claims
        self.was_corrected = was_corrected
        self.run_id = None  # set by verify_and_correct after logging


def _format_sql_section(sql_result):
    if sql_result is None:
        return "SQL data: none."
    if sql_result.error:
        return f"SQL data: query failed ({sql_result.error}) — treat as no data available."
    if not sql_result.rows:
        return f"SQL data: query ran successfully but returned no rows.\nQuery: {sql_result.generated_sql}"
    lines = [f"SQL data (from query: {sql_result.generated_sql}):", f"columns: {sql_result.columns}"]
    for row in sql_result.rows:
        lines.append(f"  {row}")
    return "\n".join(lines)


def _format_rag_section(rag_chunks):
    if not rag_chunks:
        return "RAG passages: none."
    lines = ["RAG passages:"]
    for chunk in rag_chunks:
        lines.append(f"  [{chunk.table}#{chunk.row_id}] (relevance {chunk.score:.2f}) {chunk.text}")
    return "\n".join(lines)


def _parse_claims(raw_output):
    text = _CODE_FENCE_RE.sub("", raw_output).strip()
    try:
        parsed = json.loads(text)
        raw_claims = parsed.get("claims", [])
    except (json.JSONDecodeError, AttributeError) as exc:
        logger.warning("failed to parse verification output raw=%r error=%s", raw_output, exc)
        return []

    claims = []
    for c in raw_claims:
        try:
            claims.append(
                {
                    "text": str(c["text"]),
                    "supported": bool(c["supported"]),
                    "confidence": float(c.get("confidence", 0.5)),
                    "evidence": str(c.get("evidence", "")),
                    "correct_value": c.get("correct_value") or None,
                }
            )
        except (KeyError, TypeError, ValueError):
            logger.warning("skipping malformed claim entry: %r", c)
    return claims


def verify_and_correct(question, route, answer, sql_result=None, rag_chunks=None):
    """Checks every factual claim in `answer` against the raw SQL/RAG data
    it was supposedly built from. Logs one VerificationLog row per claim
    (this is what makes a hallucination catch-rate computable later), and
    if any claim was flagged, produces a corrected final answer — either
    fixed from source data, or annotated as unverifiable.
    """
    sql_section = _format_sql_section(sql_result)
    rag_section = _format_rag_section(rag_chunks)

    raw_output = llm_client.verify_claims(question, answer, sql_section, rag_section)
    claims = _parse_claims(raw_output)

    flagged_claims = [c for c in claims if not c["supported"]]

    if flagged_claims:
        final_answer = llm_client.correct_answer(question, answer, flagged_claims)
    else:
        final_answer = answer

    run_id = uuid.uuid4()
    log_rows = []
    for claim in claims:
        if claim["supported"]:
            action = "passed"
        elif claim["correct_value"]:
            action = "corrected"
        else:
            action = "flagged_unverifiable"

        log_rows.append(
            VerificationLog(
                run_id=run_id,
                question=question,
                route=route,
                original_answer=answer,
                final_answer=final_answer,
                claim_text=claim["text"],
                supported=claim["supported"],
                confidence=claim["confidence"],
                evidence=claim["evidence"],
                action_taken=action,
            )
        )
    VerificationLog.objects.bulk_create(log_rows)

    logger.info(
        "question=%r claims=%d flagged=%d corrected=%s run_id=%s",
        question, len(claims), len(flagged_claims), final_answer != answer, run_id,
    )

    result = VerificationResult(
        question=question,
        original_answer=answer,
        final_answer=final_answer,
        claims=claims,
        was_corrected=(final_answer != answer),
    )
    result.run_id = run_id
    return result
