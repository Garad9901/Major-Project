# Copyright (c) 2026 Yash Garad. All rights reserved.

from django.urls import include, path

urlpatterns = [
    path("api/health/", include("health.urls")),
    path("api/auth/", include("accounts.urls")),
    path("api/ask/", include("orchestrator.urls")),
]
