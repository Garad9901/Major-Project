# Copyright (c) 2026 Yash Garad. All rights reserved.

import os
from pathlib import Path

from dotenv import load_dotenv

load_dotenv()

BASE_DIR = Path(__file__).resolve().parent.parent

SECRET_KEY = os.getenv("DJANGO_SECRET_KEY", "dev-insecure-secret-key-change-me")
DEBUG = os.getenv("DJANGO_DEBUG", "true").lower() == "true"
ALLOWED_HOSTS = os.getenv("DJANGO_ALLOWED_HOSTS", "*").split(",")

# The public host/IP the assistant is reached at (behind the HTTPS proxy).
SERVER_HOST = os.getenv("SERVER_HOST", "localhost")

# --- HTTPS / cookie hardening -------------------------------------------------
# The stack sits behind the Caddy reverse proxy, which terminates TLS and
# forwards X-Forwarded-Proto so Django knows the original request was HTTPS.
SECURE_PROXY_SSL_HEADER = ("HTTP_X_FORWARDED_PROTO", "https")

# Turn on Secure cookies once served over HTTPS (default on). Set
# COOKIE_SECURE=false only if you deliberately run plain HTTP.
_cookie_secure = os.getenv("COOKIE_SECURE", "true").lower() == "true"
SESSION_COOKIE_SECURE = _cookie_secure
CSRF_COOKIE_SECURE = _cookie_secure
SESSION_COOKIE_HTTPONLY = True  # session cookie is never readable by JavaScript
SESSION_COOKIE_SAMESITE = "Lax"
CSRF_COOKIE_SAMESITE = "Lax"

# The browser reaches the SPA + API through the proxy over HTTPS, so that
# origin must be trusted for CSRF-protected POSTs.
CSRF_TRUSTED_ORIGINS = [
    f"https://{SERVER_HOST}",
    "https://localhost",
]

INSTALLED_APPS = [
    "django.contrib.contenttypes",
    "django.contrib.auth",
    "django.contrib.sessions",
    "django.contrib.staticfiles",
    "rest_framework",
    "rest_framework.authtoken",
    "corsheaders",
    "accounts",
    "health",
    "academics",
    "sql_agent",
    "rag_agent",
    "router_agent",
    "synthesis_agent",
    "verification_agent",
    "orchestrator",
    "experiments",
    "audit",
]

MIDDLEWARE = [
    "corsheaders.middleware.CorsMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
]

ROOT_URLCONF = "config.urls"

TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.debug",
                "django.template.context_processors.request",
            ],
        },
    },
]

WSGI_APPLICATION = "config.wsgi.application"
ASGI_APPLICATION = "config.asgi.application"

DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.postgresql",
        "NAME": os.getenv("POSTGRES_DB", "college_rag"),
        "USER": os.getenv("POSTGRES_USER", "postgres"),
        "PASSWORD": os.getenv("POSTGRES_PASSWORD", "postgres"),
        "HOST": os.getenv("POSTGRES_HOST", "postgres"),
        "PORT": os.getenv("POSTGRES_PORT", "5432"),
    }
}

AUTH_PASSWORD_VALIDATORS = []

LANGUAGE_CODE = "en-us"
TIME_ZONE = "UTC"
USE_I18N = True
USE_TZ = True

STATIC_URL = "static/"

DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"

REST_FRAMEWORK = {
    "DEFAULT_RENDERER_CLASSES": [
        "rest_framework.renderers.JSONRenderer",
    ],
    # Session-cookie auth (httpOnly, CSRF-protected) rather than a token the
    # browser stores in localStorage where injected JS could read it.
    "DEFAULT_AUTHENTICATION_CLASSES": [
        "rest_framework.authentication.SessionAuthentication",
    ],
    # Everything requires an authenticated session unless it explicitly opts
    # out (login/csrf). /api/ask/ further narrows this to staff.
    "DEFAULT_PERMISSION_CLASSES": [
        "rest_framework.permissions.IsAuthenticated",
    ],
    # Per-user rate limits. The 'ask' scope is applied by AskRateThrottle on
    # the assistant endpoint (see accounts/throttling.py).
    "DEFAULT_THROTTLE_RATES": {
        "ask": "10/min",
    },
}

# Dev-only: allow the Vite dev server to call the API from the browser.
CORS_ALLOW_ALL_ORIGINS = DEBUG
CORS_ALLOWED_ORIGINS = os.getenv("CORS_ALLOWED_ORIGINS", "").split(",") if not DEBUG else []

# Ollama / Qdrant connection info, used by sql_agent and (later) other RAG code.
OLLAMA_BASE_URL = os.getenv("OLLAMA_BASE_URL", "http://ollama:11434")
QDRANT_URL = os.getenv("QDRANT_URL", "http://qdrant:6333")

# Ensures sql_agent's "log every generated query before execution" requirement
# is actually visible: Django's default logging only surfaces WARNING+ for
# unconfigured loggers, which would silently swallow the INFO-level audit log.
LOGGING = {
    "version": 1,
    "disable_existing_loggers": False,
    "handlers": {
        "console": {
            "class": "logging.StreamHandler",
        },
    },
    "loggers": {
        "sql_agent": {
            "handlers": ["console"],
            "level": "INFO",
            "propagate": False,
        },
        "rag_agent": {
            "handlers": ["console"],
            "level": "INFO",
            "propagate": False,
        },
        "router_agent": {
            "handlers": ["console"],
            "level": "INFO",
            "propagate": False,
        },
        "synthesis_agent": {
            "handlers": ["console"],
            "level": "INFO",
            "propagate": False,
        },
        "verification_agent": {
            "handlers": ["console"],
            "level": "INFO",
            "propagate": False,
        },
        "orchestrator": {
            "handlers": ["console"],
            "level": "INFO",
            "propagate": False,
        },
    },
}
