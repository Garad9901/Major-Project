# Copyright (c) 2026 Yash Garad. All rights reserved.

from django.urls import path

from .views import health_check, liveness

urlpatterns = [
    path("", health_check, name="health-check"),
    path("live/", liveness, name="health-live"),
]
