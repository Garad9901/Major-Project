# Copyright (c) 2026 Yash Garad. All rights reserved.

from django.db import models

# ============================================================================
# General institutional data — safe for the read-only RAG agent
# (rag_agent_ro is granted SELECT on these tables; see db/sql/create_rag_agent_ro.sql)
# ============================================================================


class Department(models.Model):
    name = models.CharField(max_length=150, unique=True)
    code = models.CharField(max_length=10, unique=True)
    established_year = models.PositiveIntegerField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "departments"

    def __str__(self):
        return self.name


class Faculty(models.Model):
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    email = models.EmailField(unique=True)
    phone = models.CharField(max_length=20, blank=True)
    designation = models.CharField(max_length=100, blank=True)
    department = models.ForeignKey(
        Department, on_delete=models.SET_NULL, null=True, related_name="faculty_members"
    )
    joined_date = models.DateField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "faculty"

    def __str__(self):
        return f"{self.first_name} {self.last_name}"


class Program(models.Model):
    DEGREE_CHOICES = [
        ("bachelor", "Bachelor's"),
        ("master", "Master's"),
        ("diploma", "Diploma"),
        ("phd", "PhD"),
    ]
    name = models.CharField(max_length=150)
    degree_level = models.CharField(max_length=20, choices=DEGREE_CHOICES)
    department = models.ForeignKey(Department, on_delete=models.CASCADE, related_name="programs")
    duration_years = models.PositiveSmallIntegerField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "programs"

    def __str__(self):
        return self.name


class Course(models.Model):
    code = models.CharField(max_length=20, unique=True)
    title = models.CharField(max_length=200)
    credits = models.PositiveSmallIntegerField()
    department = models.ForeignKey(Department, on_delete=models.CASCADE, related_name="courses")
    description = models.TextField(blank=True)
    prerequisites = models.ManyToManyField(
        "self", symmetrical=False, blank=True, related_name="required_for"
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "courses"

    def __str__(self):
        return f"{self.code} - {self.title}"


class Room(models.Model):
    building = models.CharField(max_length=100)
    room_number = models.CharField(max_length=20)
    capacity = models.PositiveIntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "rooms"
        unique_together = ("building", "room_number")

    def __str__(self):
        return f"{self.building} {self.room_number}"


class CourseOffering(models.Model):
    course = models.ForeignKey(Course, on_delete=models.CASCADE, related_name="offerings")
    instructor = models.ForeignKey(
        Faculty, on_delete=models.SET_NULL, null=True, related_name="course_offerings"
    )
    semester = models.CharField(max_length=20)
    section = models.CharField(max_length=10, default="A")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "course_offerings"
        unique_together = ("course", "semester", "section")

    def __str__(self):
        return f"{self.course.code} [{self.semester} {self.section}]"


class ClassSchedule(models.Model):
    DAY_CHOICES = [
        ("mon", "Monday"),
        ("tue", "Tuesday"),
        ("wed", "Wednesday"),
        ("thu", "Thursday"),
        ("fri", "Friday"),
        ("sat", "Saturday"),
    ]
    course_offering = models.ForeignKey(
        CourseOffering, on_delete=models.CASCADE, related_name="schedule_slots"
    )
    day_of_week = models.CharField(max_length=3, choices=DAY_CHOICES)
    start_time = models.TimeField()
    end_time = models.TimeField()
    room = models.ForeignKey(Room, on_delete=models.SET_NULL, null=True, related_name="class_schedules")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "class_schedule"

    def __str__(self):
        return f"{self.course_offering} {self.day_of_week} {self.start_time}-{self.end_time}"


class ExamTimetable(models.Model):
    course = models.ForeignKey(Course, on_delete=models.CASCADE, related_name="exam_slots")
    exam_date = models.DateField()
    start_time = models.TimeField()
    end_time = models.TimeField()
    room = models.ForeignKey(Room, on_delete=models.SET_NULL, null=True, related_name="exam_slots")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "exam_timetable"

    def __str__(self):
        return f"{self.course.code} exam on {self.exam_date}"


class FeeStructure(models.Model):
    program = models.ForeignKey(Program, on_delete=models.CASCADE, related_name="fee_structures")
    semester = models.CharField(max_length=20)
    fee_type = models.CharField(max_length=50)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "fee_structure"

    def __str__(self):
        return f"{self.program} {self.semester} {self.fee_type}"


# ============================================================================
# Per-student data — NOT granted to rag_agent_ro. Personal/sensitive:
# identity, academic performance, attendance, and payment history.
# ============================================================================


class Student(models.Model):
    roll_number = models.CharField(max_length=20, unique=True)
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    email = models.EmailField(unique=True)
    phone = models.CharField(max_length=20, blank=True)
    date_of_birth = models.DateField(null=True, blank=True)
    program = models.ForeignKey(Program, on_delete=models.SET_NULL, null=True, related_name="students")
    batch_year = models.PositiveIntegerField()

    class Meta:
        db_table = "students"

    def __str__(self):
        return f"{self.roll_number} - {self.first_name} {self.last_name}"


class Enrollment(models.Model):
    STATUS_CHOICES = [("active", "Active"), ("completed", "Completed"), ("dropped", "Dropped")]
    student = models.ForeignKey(Student, on_delete=models.CASCADE, related_name="enrollments")
    course_offering = models.ForeignKey(
        CourseOffering, on_delete=models.CASCADE, related_name="enrollments"
    )
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default="active")
    enrolled_on = models.DateField(auto_now_add=True)

    class Meta:
        db_table = "enrollments"
        unique_together = ("student", "course_offering")

    def __str__(self):
        return f"{self.student.roll_number} -> {self.course_offering}"


class Attendance(models.Model):
    STATUS_CHOICES = [("present", "Present"), ("absent", "Absent"), ("excused", "Excused")]
    enrollment = models.ForeignKey(Enrollment, on_delete=models.CASCADE, related_name="attendance_records")
    date = models.DateField()
    status = models.CharField(max_length=10, choices=STATUS_CHOICES)

    class Meta:
        db_table = "attendance"
        unique_together = ("enrollment", "date")


class ExamResult(models.Model):
    enrollment = models.ForeignKey(Enrollment, on_delete=models.CASCADE, related_name="exam_results")
    exam_type = models.CharField(max_length=50)
    marks_obtained = models.DecimalField(max_digits=6, decimal_places=2)
    max_marks = models.DecimalField(max_digits=6, decimal_places=2)
    grade = models.CharField(max_length=5, blank=True)

    class Meta:
        db_table = "exam_results"


class FeePayment(models.Model):
    student = models.ForeignKey(Student, on_delete=models.CASCADE, related_name="fee_payments")
    fee_structure = models.ForeignKey(
        FeeStructure, on_delete=models.SET_NULL, null=True, related_name="payments"
    )
    amount_paid = models.DecimalField(max_digits=10, decimal_places=2)
    payment_date = models.DateField()
    status = models.CharField(max_length=20, default="paid")

    class Meta:
        db_table = "fee_payments"
