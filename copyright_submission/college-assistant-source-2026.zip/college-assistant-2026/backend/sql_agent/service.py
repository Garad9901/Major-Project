# Copyright (c) 2026 Yash Garad. All rights reserved.

import logging

import psycopg2

from common.exceptions import DatabaseUnavailable

from . import db, executor, guard, llm_client, schema

logger = logging.getLogger("sql_agent")

CONNECT_TIMEOUT_S = 5


class SqlAgentResult:
    def __init__(self, question, raw_llm_output=None, generated_sql=None, columns=None, rows=None, error=None):
        self.question = question
        self.raw_llm_output = raw_llm_output
        self.generated_sql = generated_sql
        self.columns = columns
        self.rows = rows
        self.error = error

    @property
    def ok(self):
        return self.error is None


def ask(question, execute=True):
    """Natural language question -> validated+capped SQL -> (optionally) results.

    Every generated query is logged via the "sql_agent" logger *before* it's
    ever executed — including ones that get rejected — so there's always an
    audit trail of what the LLM produced, independent of whether it ran.
    """
    # Schema introspection connects to the DB; if it's unreachable, fail fast
    # with a user-safe DatabaseUnavailable rather than a raw psycopg2 trace.
    try:
        conn = psycopg2.connect(connect_timeout=CONNECT_TIMEOUT_S, **db.RAG_AGENT_RO_CONFIG)
    except psycopg2.OperationalError as exc:
        raise DatabaseUnavailable(f"could not connect to database: {exc}") from exc
    try:
        schema_text = schema.build_schema_text(conn)
    except psycopg2.OperationalError as exc:
        raise DatabaseUnavailable(f"database connection lost during schema read: {exc}") from exc
    finally:
        try:
            conn.close()
        except Exception:
            pass

    raw_output = llm_client.generate_sql(question, schema_text)

    try:
        capped_sql = guard.validate_and_cap(raw_output, schema.ALLOWED_TABLES)
    except guard.SqlRejected as exc:
        logger.warning("REJECTED question=%r raw_llm_output=%r reason=%s", question, raw_output, exc)
        return SqlAgentResult(question, raw_llm_output=raw_output, error=str(exc))

    logger.info("question=%r generated_sql=%s", question, capped_sql)

    if not execute:
        return SqlAgentResult(question, raw_llm_output=raw_output, generated_sql=capped_sql)

    try:
        columns, rows = executor.run_query(capped_sql)
    except DatabaseUnavailable:
        # Infrastructure failure — let the orchestrator decide how to degrade,
        # instead of burying a raw error string in the result.
        raise
    except Exception as exc:
        # A query-level error (e.g. Postgres rejects a valid-looking SELECT).
        # This is data-shaped, not infrastructure — record it and carry on.
        logger.exception("query execution failed question=%r sql=%s", question, capped_sql)
        return SqlAgentResult(question, raw_llm_output=raw_output, generated_sql=capped_sql, error=str(exc))

    return SqlAgentResult(
        question, raw_llm_output=raw_output, generated_sql=capped_sql, columns=columns, rows=rows
    )
