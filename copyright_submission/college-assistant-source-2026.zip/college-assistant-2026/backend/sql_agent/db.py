# Copyright (c) 2026 Yash Garad. All rights reserved.

import os

# Deliberately NOT Django's own DB connection (that's the app-owner user).
# The SQL agent — both for schema introspection and for running
# LLM-generated queries — only ever connects as rag_agent_ro, so a bug here
# can't do more than that role's grants allow (see db/sql/create_rag_agent_ro.sql).
RAG_AGENT_RO_CONFIG = {
    "host": os.getenv("RAG_AGENT_RO_HOST", os.getenv("POSTGRES_HOST", "postgres")),
    "port": os.getenv("RAG_AGENT_RO_PORT", os.getenv("POSTGRES_PORT", "5432")),
    "dbname": os.getenv("RAG_AGENT_RO_DB", os.getenv("POSTGRES_DB", "college_rag")),
    "user": os.getenv("RAG_AGENT_RO_USER", "rag_agent_ro"),
    "password": os.getenv("RAG_AGENT_RO_PASSWORD"),
}
