# Copyright (c) 2026 Yash Garad. All rights reserved.

import logging

from . import llm_client

logger = logging.getLogger("synthesis_agent")


def _format_sql_section(sql_result):
    """sql_result is duck-typed to match sql_agent.service.SqlAgentResult:
    .error, .generated_sql, .columns, .rows."""
    if sql_result is None:
        return "SQL data: none."
    if sql_result.error:
        return f"SQL data: query failed ({sql_result.error}) — treat as no data available."
    if not sql_result.rows:
        return f"SQL data: query ran successfully but returned no rows.\nQuery: {sql_result.generated_sql}"

    lines = [f"SQL data (from query: {sql_result.generated_sql}):", f"columns: {sql_result.columns}"]
    for row in sql_result.rows:
        lines.append(f"  {row}")
    return "\n".join(lines)


def _format_rag_section(rag_chunks):
    """rag_chunks is duck-typed to match a list of rag_agent.service.RetrievedChunk:
    .table, .row_id, .score, .text."""
    if not rag_chunks:
        return "RAG passages: none."

    lines = ["RAG passages:"]
    for chunk in rag_chunks:
        lines.append(f"  [{chunk.table}#{chunk.row_id}] (relevance {chunk.score:.2f}) {chunk.text}")
    return "\n".join(lines)


def synthesize_answer(question, route, sql_result=None, rag_chunks=None):
    sql_section = _format_sql_section(sql_result)
    rag_section = _format_rag_section(rag_chunks)

    answer = llm_client.synthesize(question, route, sql_section, rag_section)

    logger.info(
        "question=%r route=%s sql_rows=%d rag_chunks=%d",
        question, route,
        len(sql_result.rows) if sql_result and sql_result.rows else 0,
        len(rag_chunks) if rag_chunks else 0,
    )
    return answer


def synthesize_answer_stream(question, route, sql_result=None, rag_chunks=None):
    """Streaming variant of synthesize_answer: yields the answer in pieces as
    the model generates them."""
    sql_section = _format_sql_section(sql_result)
    rag_section = _format_rag_section(rag_chunks)

    logger.info(
        "streaming question=%r route=%s sql_rows=%d rag_chunks=%d",
        question, route,
        len(sql_result.rows) if sql_result and sql_result.rows else 0,
        len(rag_chunks) if rag_chunks else 0,
    )
    yield from llm_client.synthesize_stream(question, route, sql_section, rag_section)
