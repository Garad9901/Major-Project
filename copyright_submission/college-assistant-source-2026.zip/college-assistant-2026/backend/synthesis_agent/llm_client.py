# Copyright (c) 2026 Yash Garad. All rights reserved.

import os

from common import ollama

# LLM_MODEL is the single knob for the model all agents use; SYNTHESIS_MODEL is
# an optional per-agent override that defaults to it.
SYNTHESIS_MODEL = os.getenv("SYNTHESIS_MODEL", os.getenv("LLM_MODEL", "qwen2.5:7b"))

SYSTEM_PROMPT = """You are the final-answer writer for a college information assistant. You are given a user's question plus data gathered by two upstream systems:

- SQL data: exact rows pulled from the college database. Treat this as ground truth — never contradict it, never round or alter its numbers, never omit a fact it contains that the question asked for.
- RAG passages: descriptive text retrieved by semantic search over course/department/faculty/program descriptions. Use this for context, explanation, and descriptive content.

Rules:
- If SQL data is present, it is the source of truth for any specific fact, count, date, or number. If a RAG passage disagrees with SQL data on a fact, go with the SQL data.
- If SQL data is present but empty (no rows), say plainly that no matching records were found — do not invent an answer.
- If RAG passages are present, weave them in naturally for description/context. If none are relevant to the question, ignore them rather than forcing them in.
- If both SQL data and RAG passages are present, merge them into one coherent answer — don't just concatenate two separate answers.
- Write in plain, natural language for the end user. Never mention "SQL agent", "RAG agent", "the router", table/column names, or that this involved multiple systems.
- Be concise. No preamble like "Based on the data provided" — just answer.
"""


def _build_user_prompt(question, route, sql_section, rag_section):
    return f"""User question: {question}

Route: {route}

{sql_section}

{rag_section}

Write the final answer."""


def _messages(question, route, sql_section, rag_section):
    return [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": _build_user_prompt(question, route, sql_section, rag_section)},
    ]


def synthesize(question, route, sql_section, rag_section):
    # Raises common.exceptions.LLMUnavailable if Ollama is down/slow.
    content = ollama.chat(
        SYNTHESIS_MODEL,
        messages=_messages(question, route, sql_section, rag_section),
        options={"temperature": 0.2},
    )
    return content.strip()


def synthesize_stream(question, route, sql_section, rag_section):
    """Yields answer text token-by-token as Ollama generates it, so the API
    can stream to the client instead of waiting for the full answer. Raises
    LLMUnavailable if Ollama is down/slow or the stream drops mid-answer."""
    yield from ollama.chat_stream(
        SYNTHESIS_MODEL,
        messages=_messages(question, route, sql_section, rag_section),
        options={"temperature": 0.2},
    )
