# Copyright (c) 2026 Yash Garad. All rights reserved.

import logging
from concurrent.futures import ThreadPoolExecutor

from common.exceptions import (
    DatabaseUnavailable,
    ServiceUnavailable,
    VectorStoreUnavailable,
)
from rag_agent.service import retrieve
from router_agent.classifier import classify
from sql_agent.service import ask as sql_ask
from synthesis_agent.service import synthesize_answer, synthesize_answer_stream

logger = logging.getLogger("orchestrator")

DEFAULT_ROUTE_ON_ERROR = "BOTH"
RAG_TOP_K = 5

# User-facing degradation notes appended to an answer when one source is down
# but we could still answer from the other.
DB_DOWN_NOTE = (
    "Note: live records lookup is temporarily unavailable, so this answer is "
    "based on descriptive information only."
)
RAG_DOWN_NOTE = (
    "Note: descriptive search is temporarily unavailable, so this answer is "
    "based on the structured records only."
)
RAG_DOWN_SQL_FALLBACK_NOTE = (
    "Note: descriptive search is temporarily unavailable; answering from the "
    "structured records instead."
)


def _resolve_route(question):
    # classify() can raise LLMUnavailable (Ollama down) — we let that propagate,
    # since if the LLM is down synthesis can't run either. A *parse* failure
    # (route_result.error) is different: fall back to BOTH and carry on.
    route_result = classify(question)
    if route_result.error:
        logger.warning(
            "router failed question=%r error=%s — falling back to %s",
            question, route_result.error, DEFAULT_ROUTE_ON_ERROR,
        )
        return DEFAULT_ROUTE_ON_ERROR, f"router error, defaulted to {DEFAULT_ROUTE_ON_ERROR}"
    return route_result.route, route_result.reason


def _run_sql(question):
    return sql_ask(question, execute=True)


def _run_rag(question):
    return retrieve(question, top_k=RAG_TOP_K)


def _gather_sources(question, route):
    """Fetch SQL and/or RAG data for the route, degrading gracefully when ONE
    source is down. Returns (sql_result, rag_chunks, effective_route, notes).

    Raises a ServiceUnavailable only when no usable source remains (e.g. a
    SQL-only question with the database down, or a descriptive question with
    the vector store down and no useful SQL fallback). LLMUnavailable from the
    embed/generate steps propagates untouched — if the LLM is down, the whole
    request can't be served anyway.
    """
    needs_sql = route in ("SQL", "BOTH")
    needs_rag = route in ("RAG", "BOTH")
    sql_result = None
    rag_chunks = None
    notes = []

    if needs_sql and needs_rag:
        # Independent I/O — run concurrently, but tolerate either one failing.
        with ThreadPoolExecutor(max_workers=2) as pool:
            f_sql = pool.submit(_run_sql, question)
            f_rag = pool.submit(_run_rag, question)
            try:
                sql_result = f_sql.result()
            except DatabaseUnavailable as exc:
                logger.warning("SQL source down (route=BOTH), degrading to RAG-only: %s", exc)
                notes.append(DB_DOWN_NOTE)
            try:
                rag_chunks = f_rag.result()
            except VectorStoreUnavailable as exc:
                logger.warning("RAG source down (route=BOTH), degrading to SQL-only: %s", exc)
                notes.append(RAG_DOWN_NOTE)

        if sql_result is None and rag_chunks is None:
            raise ServiceUnavailable()  # both sources down — nothing to answer from
        effective = "BOTH"
        if sql_result is not None and rag_chunks is None:
            effective = "SQL"
        elif rag_chunks is not None and sql_result is None:
            effective = "RAG"
        return sql_result, rag_chunks, effective, notes

    if needs_sql:  # SQL-only — a DB outage here is fatal (no source to fall back on)
        sql_result = _run_sql(question)
        return sql_result, None, "SQL", notes

    # RAG-only
    try:
        rag_chunks = _run_rag(question)
    except VectorStoreUnavailable:
        # Try SQL as a fallback; use it only if it actually found something.
        logger.warning("RAG source down (route=RAG), attempting SQL fallback")
        fallback = _run_sql(question)
        if fallback.rows:
            notes.append(RAG_DOWN_SQL_FALLBACK_NOTE)
            return fallback, None, "SQL", notes
        raise  # nothing useful from SQL — surface the clean "descriptive search down" message
    return None, rag_chunks, "RAG", notes


def answer_question(question):
    """Full pipeline, blocking. Returns a dict with the final answer plus
    intermediate metadata. Degrades gracefully; raises ServiceUnavailable only
    when nothing can be answered."""
    route, reason = _resolve_route(question)
    sql_result, rag_chunks, effective_route, notes = _gather_sources(question, route)
    answer = synthesize_answer(question, effective_route, sql_result=sql_result, rag_chunks=rag_chunks)
    if notes:
        answer = answer + "\n\n" + "\n".join(notes)

    logger.info("answered question=%r route=%s degraded=%s", question, effective_route, bool(notes))
    return {
        "question": question,
        "route": effective_route,
        "route_reason": reason,
        "answer": answer,
        "degraded": bool(notes),
        "notes": notes,
        "sql": _sql_meta(sql_result),
        "rag": _rag_meta(rag_chunks),
    }


def answer_question_stream(question):
    """Full pipeline, streaming. Yields ('meta', {...}), then ('token', str)
    per piece, then ('done', {...}). Degradation notes (if any) are streamed
    as trailing tokens so the user sees why the answer is limited. Raises
    ServiceUnavailable when nothing can be answered — the API layer turns that
    into a clean user-facing message."""
    route, reason = _resolve_route(question)
    sql_result, rag_chunks, effective_route, notes = _gather_sources(question, route)

    yield "meta", {
        "question": question,
        "route": effective_route,
        "route_reason": reason,
        "degraded": bool(notes),
        "sql": _sql_meta(sql_result),
        "rag": _rag_meta(rag_chunks),
    }

    pieces = []
    for piece in synthesize_answer_stream(
        question, effective_route, sql_result=sql_result, rag_chunks=rag_chunks
    ):
        pieces.append(piece)
        yield "token", piece

    for note in notes:
        note_text = "\n\n" + note
        pieces.append(note_text)
        yield "token", note_text

    logger.info("streamed answer question=%r route=%s degraded=%s", question, effective_route, bool(notes))
    yield "done", {"answer": "".join(pieces)}


def _sql_meta(sql_result):
    if sql_result is None:
        return None
    return {
        "generated_sql": sql_result.generated_sql,
        "error": sql_result.error,
        "row_count": len(sql_result.rows) if sql_result.rows else 0,
    }


def _rag_meta(rag_chunks):
    if not rag_chunks:
        return None
    return [
        {"table": c.table, "row_id": c.row_id, "score": round(c.score, 4)}
        for c in rag_chunks
    ]
