# Copyright (c) 2026 Yash Garad. All rights reserved.

from rest_framework.permissions import BasePermission


class IsStaffUser(BasePermission):
    """Only authenticated users with is_staff=True. The assistant exposes
    college data and burns local-LLM compute, so it's staff-gated — a valid
    login alone isn't enough."""

    message = "Staff access required."

    def has_permission(self, request, view):
        return bool(request.user and request.user.is_authenticated and request.user.is_staff)
