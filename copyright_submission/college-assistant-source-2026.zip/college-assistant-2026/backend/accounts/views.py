# Copyright (c) 2026 Yash Garad. All rights reserved.

from django.contrib.auth import authenticate
from django.contrib.auth import login as django_login
from django.contrib.auth import logout as django_logout
from django.middleware.csrf import get_token
from rest_framework.decorators import api_view, authentication_classes, permission_classes
from rest_framework.permissions import AllowAny
from rest_framework.response import Response


@api_view(["GET"])
@authentication_classes([])
@permission_classes([AllowAny])
def csrf(request):
    # Force CsrfViewMiddleware to set the csrftoken cookie so the SPA can read
    # it and send it back as the X-CSRFToken header on POSTs.
    get_token(request._request)
    return Response({"detail": "CSRF cookie set."})


@api_view(["POST"])
@authentication_classes([])  # login must work without a prior session/CSRF
@permission_classes([AllowAny])
def login(request):
    username = (request.data.get("username") or "").strip()
    password = request.data.get("password") or ""

    user = authenticate(request, username=username, password=password)
    if user is None:
        return Response({"error": "Invalid credentials."}, status=401)

    # Staff-only gate: a valid non-staff account still cannot get in.
    if not user.is_staff:
        return Response({"error": "This account is not authorized for staff access."}, status=403)

    # Establishes a server-side session and sets the httpOnly session cookie.
    django_login(request, user)
    return Response({"username": user.username, "is_staff": user.is_staff})


@api_view(["POST"])
def logout(request):
    django_logout(request)  # flushes the session
    return Response({"detail": "Logged out."})


@api_view(["GET"])
def me(request):
    # Requires an authenticated session (returns 403 otherwise), so the SPA
    # can ask "am I logged in?" on load.
    return Response({"username": request.user.username, "is_staff": request.user.is_staff})
