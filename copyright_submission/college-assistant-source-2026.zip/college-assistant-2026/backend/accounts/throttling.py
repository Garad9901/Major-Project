# Copyright (c) 2026 Yash Garad. All rights reserved.

from rest_framework.throttling import UserRateThrottle


class AskRateThrottle(UserRateThrottle):
    """Per-user rate limit for the assistant endpoint.

    Each /api/ask/ call fans out into several CPU-bound local-LLM calls, so an
    unthrottled user (or a hijacked session) could saturate the server and deny
    service to everyone else. The rate itself lives in
    settings.REST_FRAMEWORK['DEFAULT_THROTTLE_RATES']['ask'].

    Note: this uses Django's cache, which defaults to a per-process in-memory
    store. That's correct for the single backend process here; a multi-worker
    deployment would need a shared cache (e.g. Redis) for the limit to be global.
    """

    scope = "ask"
