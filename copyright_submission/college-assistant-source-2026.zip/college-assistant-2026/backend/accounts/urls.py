# Copyright (c) 2026 Yash Garad. All rights reserved.

from django.urls import path

from .views import csrf, login, logout, me

urlpatterns = [
    path("csrf/", csrf, name="csrf"),
    path("login/", login, name="login"),
    path("logout/", logout, name="logout"),
    path("me/", me, name="me"),
]
