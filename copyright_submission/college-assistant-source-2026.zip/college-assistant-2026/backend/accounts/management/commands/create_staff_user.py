# Copyright (c) 2026 Yash Garad. All rights reserved.

import os

from django.contrib.auth.models import User
from django.core.management.base import BaseCommand


class Command(BaseCommand):
    help = "Create (or update) a staff user for accessing the assistant."

    def add_arguments(self, parser):
        parser.add_argument("--username", default=os.getenv("STAFF_USERNAME", "staff"))
        parser.add_argument("--password", default=os.getenv("STAFF_PASSWORD", "staffpass123"))

    def handle(self, *args, **options):
        username = options["username"]
        password = options["password"]

        user, created = User.objects.get_or_create(username=username)
        user.is_staff = True
        user.set_password(password)
        user.save()

        verb = "Created" if created else "Updated"
        self.stdout.write(self.style.SUCCESS(f"{verb} staff user '{username}'."))
