# Day-to-Day Runbook

A one-page card for whoever looks after the College Assistant. **No coding knowledge needed.**
For first-time installation, see [README.md](README.md) instead — this page assumes it's already set up.

Everything below is typed into a terminal **opened in the project folder** (the folder containing
the file `docker-compose.yml`).

- **Windows:** open the folder in File Explorer, click the address bar, type `powershell`, press Enter.
- **macOS:** right-click the folder → "New Terminal at Folder."
- **Linux:** open a terminal, `cd` into the folder.

---

## Starting and stopping

| What you want | Type this |
| --- | --- |
| Start the system | `docker compose up -d` |
| Stop the system | `docker compose down` |
| Restart everything | `docker compose restart` |

Before any of these, make sure **Docker Desktop is open and running** (its whale icon should say
"Docker Desktop is running"). Nothing works until it is.

Starting takes about a minute. **The very first start ever** also downloads ~5 GB of AI models and
can take 10–20 minutes — that happens once, not every time.

`docker compose down` does **not** delete anything. Your database, your questions, and the
downloaded models all survive a stop, a restart, and a reboot of the server.

---

## Is it healthy?

Three checks, quickest first. If all three pass, the system is fine.

**1. Are all the pieces running?**
```
docker compose ps
```
You should see a row for each piece with `running` or `healthy` in the STATUS column.
`ollama-pull` showing `exited (0)` is **correct** — that one is a helper that finishes its job
and stops on purpose. Anything else saying `exited`, `restarting`, or `unhealthy` is a problem.

**2. Is the brain answering?**
Open this in a browser: `https://localhost/api/health/`

- `{"status": "ok", ...}` → everything is up.
- `{"status": "degraded", "services": {...}}` → read the list; whichever says `"down"` is the
  broken piece. Note that name — you'll need it below.

**3. Can you actually use it?**
Open `https://localhost`, log in, and ask a question like *"What courses does the Computer Science
department offer?"* If words stream back, it's genuinely working.

> The browser will warn "your connection is not private." That is expected on an internal
> network — click **Advanced → Proceed**. See the README for how to remove the warning.

---

## Viewing logs

Logs are the system telling you what it's doing. Read them whenever something looks wrong.

| What you want to see | Type this |
| --- | --- |
| Everything, live | `docker compose logs -f` |
| Just one piece, live | `docker compose logs -f backend` |
| The last 100 lines | `docker compose logs --tail 100` |
| First-run model download | `docker compose logs -f ollama-pull` |

Press **`Ctrl + C`** to stop watching. That stops the *watching*, not the system.

Replace `backend` with whichever piece you care about: `backend`, `frontend`, `postgres`,
`qdrant`, `ollama`, `sync_worker`, `caddy`.

**What you're looking for:** lines containing `ERROR`, `Traceback`, or `refused`. The last
20–30 lines before a failure are usually the useful part.

---

## Troubleshooting

Work down the list — the fixes get more drastic, so try them in order.

**The website won't open at all**
1. Is Docker Desktop running? Open it and wait for "Docker Desktop is running."
2. Run `docker compose ps`. If nothing is listed, run `docker compose up -d`.
3. If this is the first start ever, the AI models are still downloading. Watch
   `docker compose logs -f ollama-pull` and wait for `All AI models are ready.`

**The browser says "your connection is not private"**
Expected and safe on your own network. Click **Advanced → Proceed**. To stop it happening on
every machine, install the certificate — README, "Trusting the certificate."

**I can't log in**
The username and password come from the `STAFF_USERNAME` / `STAFF_PASSWORD` lines in the `.env`
file in the project folder. Open it in a text editor to check them. If you change them, run
`docker compose up -d` afterwards to apply.

**Questions return an error, or the answer never appears**
1. Check `https://localhost/api/health/` and see which service says `"down"`.
2. Restart just that piece — e.g. if `llm` is down: `docker compose restart ollama`.
3. Wait 30 seconds, then check health again.
4. Still broken? `docker compose logs --tail 100 backend` and read the last error.

**Answers are very slow**
Normal on modest hardware — the AI runs entirely on your own server. If it's unusable, switch to
a smaller model: open `.env`, change `LLM_MODEL=qwen2.5:7b` to `LLM_MODEL=qwen2.5:3b`, then run
`docker compose up -d`. See README, "Choosing the AI model."

**The assistant doesn't know about data we just added**
The search index updates on a timer (about every 30 seconds). Wait a minute, then ask again. If
it's still missing, check `docker compose logs --tail 50 sync_worker` for errors.

**Something is deeply stuck — reset without losing data**
```
docker compose down
docker compose up -d
```

**Last resort — erase everything and start over**
```
docker compose down -v
docker compose up -d
```
> ⚠️ The `-v` **permanently deletes the database, all question history, and the downloaded
> models.** Only do this if you have a backup or the data doesn't matter. The next start will
> redo the full 5 GB download.

---

## When you need to ask for help

Copy the output of both of these and send it to your technical contact:

```
docker compose ps
docker compose logs --tail 100
```

Also say: what you did, what you expected, and what happened instead.

---

*Copyright (c) 2026 Yash Garad. All rights reserved.*
