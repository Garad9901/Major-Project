# Copyright (c) 2026 Yash Garad. All rights reserved.

import os

from dotenv import load_dotenv

load_dotenv()

DB_CONFIG = {
    "host": os.getenv("RAG_AGENT_RO_HOST", os.getenv("POSTGRES_HOST", "postgres")),
    "port": os.getenv("RAG_AGENT_RO_PORT", os.getenv("POSTGRES_PORT", "5432")),
    "dbname": os.getenv("RAG_AGENT_RO_DB", os.getenv("POSTGRES_DB", "college_rag")),
    "user": os.getenv("RAG_AGENT_RO_USER", "rag_agent_ro"),
    "password": os.getenv("RAG_AGENT_RO_PASSWORD"),
}

POLL_INTERVAL_SECONDS = int(os.getenv("SYNC_WORKER_POLL_INTERVAL_SECONDS", "30"))

DATA_DIR = os.getenv("SYNC_WORKER_DATA_DIR", "data")
STATE_FILE = os.path.join(DATA_DIR, "state.json")
QUEUE_FILE = os.path.join(DATA_DIR, "change_queue.jsonl")

# Same set of tables rag_agent_ro is granted SELECT on (see
# db/sql/create_rag_agent_ro.sql) — general institutional data only, never
# the per-student tables (students, enrollments, attendance, exam_results,
# fee_payments). `courses_prerequisites` is also skipped: it's a bare M2M
# join table with no updated_at column of its own to poll against.
TABLES = [
    "departments",
    "faculty",
    "programs",
    "courses",
    "rooms",
    "course_offerings",
    "class_schedule",
    "exam_timetable",
    "fee_structure",
]

# Of the tables above, only these have free-text content worth semantic
# search (names, descriptions, designations). The rest — rooms, schedules,
# timetables, fee amounts — are structured/numeric and better served by
# direct SQL lookups than a vector store, so they're never embedded.
DESCRIPTIVE_TABLES = ["departments", "faculty", "programs", "courses"]

OLLAMA_BASE_URL = os.getenv("OLLAMA_BASE_URL", "http://ollama:11434")
EMBEDDING_MODEL = os.getenv("EMBEDDING_MODEL", "nomic-embed-text")
EMBEDDING_DIM = int(os.getenv("EMBEDDING_DIM", "768"))

QDRANT_URL = os.getenv("QDRANT_URL", "http://qdrant:6333")
QDRANT_COLLECTION = os.getenv("QDRANT_COLLECTION", "college_docs")
