# Copyright (c) 2026 Yash Garad. All rights reserved.

import logging
import time
from datetime import datetime

import psycopg2

import config
import state as state_module
from chunker import row_to_text
from embedder import embed_text
from lookups import fetch_department_lookup
from poller import poll_table
from queue_writer import append_changes
from vector_store import upsert_point

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [sync_worker] %(levelname)s: %(message)s",
)
logger = logging.getLogger("sync_worker")


def connect():
    return psycopg2.connect(**config.DB_CONFIG)


def embed_and_upsert_changes(table, changes, dept_lookup):
    for change in changes:
        try:
            text = row_to_text(table, change["row"], dept_lookup)
            vector = embed_text(text)
            upsert_point(table, change["pk"], vector, text, change["updated_at"])
            logger.info("embedded %s id=%s -> %s", table, change["pk"], text[:80])
        except Exception:
            # One bad row/embedding call shouldn't take down the whole cycle —
            # it'll simply be retried next cycle since the watermark for this
            # table only advances after this loop finishes successfully.
            logger.exception("failed to embed/upsert %s id=%s", table, change["pk"])
            raise


def run_cycle(conn, app_state):
    total_changes = 0
    dept_lookup = fetch_department_lookup(conn)

    for table in config.TABLES:
        entry = app_state.get(table, {})
        last_updated_at = datetime.fromisoformat(entry.get("last_updated_at", state_module.EPOCH))
        seen_ids = set(entry.get("seen_ids_at_last_ts", []))

        changes, new_last_updated_at, new_seen_ids = poll_table(conn, table, last_updated_at, seen_ids)

        if changes:
            for change in changes:
                logger.info(
                    "%-18s %-8s id=%-5s updated_at=%s",
                    table, change["op"], change["pk"], change["updated_at"],
                )
            append_changes(changes)
            total_changes += len(changes)

            if table in config.DESCRIPTIVE_TABLES:
                embed_and_upsert_changes(table, changes, dept_lookup)

        app_state[table] = {
            "last_updated_at": new_last_updated_at.isoformat(),
            "seen_ids_at_last_ts": sorted(new_seen_ids),
        }
        # Persist after every table, not just at the end of the cycle, so a
        # crash mid-cycle doesn't re-process tables already handled this run.
        state_module.save_state(app_state)

    if total_changes:
        logger.info("poll cycle complete: %d change(s) detected", total_changes)
    else:
        logger.info("poll cycle complete: no changes detected")


def main():
    logger.info("sync_worker starting")
    logger.info("polling tables: %s", ", ".join(config.TABLES))
    logger.info("embedding + upserting to Qdrant for: %s", ", ".join(config.DESCRIPTIVE_TABLES))
    logger.info("poll interval: %ds", config.POLL_INTERVAL_SECONDS)

    app_state = state_module.load_state()

    while True:
        try:
            conn = connect()
            try:
                run_cycle(conn, app_state)
            finally:
                conn.close()
        except psycopg2.Error as exc:
            logger.error("database error during poll cycle: %s", exc)
        except Exception:
            logger.exception("unexpected error during poll cycle")

        time.sleep(config.POLL_INTERVAL_SECONDS)


if __name__ == "__main__":
    main()
