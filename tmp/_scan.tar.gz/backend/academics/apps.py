# Copyright (c) 2026 Yash Garad. All rights reserved.

from django.apps import AppConfig


class AcademicsConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "academics"
